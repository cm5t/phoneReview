//
//  Lesson 6 SUI View.swift
//  Lesson 6
//
//  Created by Dylan Kwok Heng Yi on 14/08/2023.
//

import SwiftUI

struct Lesson_6_SUI_View: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Lesson_6_SUI_View_Previews: PreviewProvider {
    static var previews: some View {
        Lesson_6_SUI_View()
    }
}
