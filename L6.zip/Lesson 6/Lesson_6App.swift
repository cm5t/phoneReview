//
//  Lesson_6App.swift
//  Lesson 6
//
//  Created by Dylan Kwok Heng Yi on 14/08/2023.
//

import SwiftUI

@main
struct Lesson_6App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
