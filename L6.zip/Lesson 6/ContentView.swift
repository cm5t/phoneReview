//
//  ContentView.swift
//  Lesson 6
//
//  Created by Dylan Kwok Heng Yi on 14/08/2023.
//

import SwiftUI

struct Phones: Identifiable{
    var id = UUID()
    var name: String
    var performanceVal: Int
    var priceVal: Int
    var hash: Int
    var comments: String
}

struct ContentView: View {
    @State var hello = "At"
    @State var Sheetshown = false
    @State var phoneData = [
        Phones(name: "Nokia", performanceVal: 1, priceVal: 10, hash: 1, comments: "unbreakable"),
        Phones(name: "Samsung Galaxy ZFlip 4", performanceVal: 7, priceVal: 1, hash: 2, comments: "flexible phone"),
        Phones(name: "Apple iPhone 14 Pro Max", performanceVal: 8, priceVal: 3, hash: 3, comments: "best phone")
    ]
    var phones: [String] {
            phoneData.map { phone in
                "\(phone.name) (Performance: \(phone.performanceVal)/10, Price \(phone.priceVal)/10)"
            }
        }
    var body: some View {
        NavigationStack{
            VStack {
                List{
                    ForEach(phoneData) { phone in
                        NavigationLink {
                            Text("(Performance: \(phone.performanceVal)/10, Price \(phone.priceVal)/10)")
                                .offset(y:-50)
                            Text(phone.comments)
                                .offset(y:150)
                        } label: {
                            Text("\(phone.name)")
                        }
                        .id(phone.id)  // Use the id property of the Phones struct as the identifier
                    }

                    }
                }
                .navigationTitle("Mobile Phones")
                .sheet(isPresented: $Sheetshown) {
                    DetailView(BindedHello: $hello)
                }
                
                .toolbar {
                    ToolbarItem {
                        NavigationLink {
                            Text("New Phone")
                            } label: {
                                Text("+")
                            }
                        }
                    }
                }
            }
        }
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
